import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class APROG_DEI_DD_1190782_1190811 {

    static Scanner lerResposta = new Scanner(System.in);
    static final int MAX_SELECOES = 32;
    static final int MAX_STATS = 9;
    static final int MAX_IDENT = 2;
    public static final String ANSI_WHITE = "\u001B[30m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String GREEN_BOLD = "\033[1;32m";
    public static final String CYAN_BOLD = "\033[1;36m";

    public static void main(String[] args) throws FileNotFoundException, IOException {

        String[][] ident = new String[MAX_SELECOES][MAX_IDENT];
        int[][] stats = new int[MAX_SELECOES][MAX_STATS]; //Guarda as estatisticas das equipas na forma seguinte: 0 -> J; 1 -> V; 2 -> E; 3 -> D; 4 -> GM; 5 -> GS; 6 -> GD (GM - GS); 7 -> Posicao; (8 -> Pontos);

        int quantidadeDeEquipas = 0, verificacao = 0;
        String resposta = null;
        menu(ident, stats, verificacao, quantidadeDeEquipas, resposta);
    }

    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    private static void menu(String[][] ident, int[][] stats, int verificacao, int quantidadeDeEquipas, String resposta) throws FileNotFoundException, IOException {
        System.out.print(GREEN_BOLD + "     ⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽ ");
        System.out.print(ANSI_YELLOW + " MUNDIAL");
        System.out.println(ANSI_RED + " ⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽🏆⚽ ");
        System.out.println(ANSI_WHITE);
        System.out.println("                                Olá, este programa trata da informação do campeonato mundial de futebol!");
        System.out.println("                         A seguir encontra-se um menu. Digite o número da funcionalidade que pretende executar:");
        System.out.println();
        System.out.println("  ---------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println(" | 1 - Ler a informação disponível no ficheiro de texto (PracticalWork.csv) e armazená-la em memória.                                    |");
        System.out.println(" | 2 - Inserir informação de uma seleção no seguinte formanto: (B,Portugal,3,1,2,0,5,4)                                                  |");
        System.out.println(" | 3 - Calcular e armazenar em memória a pontuação de todas as equipas.                                                                  |");
        System.out.println(" | 4 - Calcular e armazenar em memória a classificação de todas as equipas nos respetivos grupos.                                        |");
        System.out.println(" | 5 - Listar a classificação das equipas por grupo.                                                                                     |");
        System.out.println(" | 6 - Listar as equipas cujos golos marcados é igual ao máximo de golos marcados.                                                       |");
        System.out.println(" | 7 - Listar as equipas com um determinado número de golos sofridos (inserir posteriormente o número de golos sofridos).                |");
        System.out.println(" | 8 - Listar as equipas que têm mais golos sofridos do que golos marcados, ordenadas alfabeticamente.                                   |");
        System.out.println(" | 9 - Listar o primeiro classificado de cada grupo.                                                                                     |");
        System.out.println(" | 10 - Listar informação completa de uma equipa (inserir posteriormente o nome da equipa).                                              |");
        System.out.println(" | 11 - Criar um ficheiro de texto com estatísticas dos jogos.                                                                           |");
        System.out.println(" | 12 - Remover da memória as equipas que não vão disputar a fase seguinte (3º e 4º classificados de cada grupo).                        |");
        System.out.println(" | 13 - Criar um ficheiro de texto com as equipas que vão disputar a fase seguinte do campeonato.                                        |");
        System.out.println(" | 14 - Criar um ficheiro de texto com os jogos da fase final.                                                                           |");
        System.out.println(" | Sair - Terminar o programa.                                                                                                           |");
        System.out.println(" -  ------------------------------------------------------------  --.*.--  ------------------------------------------------------------  -");
        System.out.println();
        System.out.println("O que deseja executar?");
        System.out.println();
        String comando = lerResposta.nextLine();
        System.out.println();
        if (!(comando.trim()).equalsIgnoreCase("Sair")) {
            while (!(comando.trim()).equalsIgnoreCase("Sair")) {
                switch (comando.trim()) {
                    case "1"://Ler a informação disponível no ficheiro de texto (PracticalWork.csv) e armazená-la em memória.
                        leituraDoFicheiro(ident, stats);
                        verificacao = 4;
                        System.out.println(CYAN_BOLD + "O ficheiro foi lido com sucesso.");
                        break;
                    case "2"://Inserir informação de uma seleção no seguinte formato: (B,Portugal,3,1,2,0,5,4).
                        acrescentar(ident, stats);
                        quantidadeDeEquipas = quantidadeEquipas(stats);
                        diferencaGolos(stats, quantidadeDeEquipas);
                        pontuacao(ident, stats);
                        classificacoes(ident, stats);
                        verificacao = 4;
                        break;
                    case "3"://Calcular e armazenar em memória a pontuação de todas as equipas.
                        Scanner lerResposta11 = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            quantidadeDeEquipas = quantidadeEquipas(stats);
                            diferencaGolos(stats, quantidadeDeEquipas);
                            pontuacao(ident, stats);
                            verificacao = 4;
                            System.out.println(CYAN_BOLD + "A pontuação foi calculada e armazenada.");
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Não tem quaisquer dados em memoria!");
                            System.out.println(ANSI_WHITE);
                            System.out.println("Deseja executar os comandos 1, 2, 3, 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerResposta11.next();
                            System.out.println();
                            if (resposta.equalsIgnoreCase("Sim")) {
                                leituraDoFicheiro(ident, stats);
                                quantidadeDeEquipas = quantidadeEquipas(stats);
                                diferencaGolos(stats, quantidadeDeEquipas);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                verificacao = 4;
                                System.out.println(CYAN_BOLD + "A pontuação foi calculada e armazenada.");
                                break;
                            } else {
                                System.out.println(ANSI_RED + "Nesse caso não é possível executar esta funcionalidade.");
                            }
                            break;
                        }
                    case "4"://Calcular e armazenar em memória a classificação de todas as equipas nos respetivos grupos.
                        Scanner lerResposta12 = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            quantidadeDeEquipas = quantidadeEquipas(stats);
                            diferencaGolos(stats, quantidadeDeEquipas);
                            classificacoes(ident, stats);
                            verificacao = 4;
                            System.out.println(CYAN_BOLD + "A classificação de todas as equipas foi calculada e armazenada.");
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Não tem quaisquer dados em memoria!");
                            System.out.println(ANSI_WHITE);
                            System.out.println("Deseja executar os comandos 1, 2, 3, 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerResposta12.next();
                            System.out.println();
                            if (resposta.equalsIgnoreCase("Sim")) {
                                leituraDoFicheiro(ident, stats);
                                quantidadeDeEquipas = quantidadeEquipas(stats);
                                diferencaGolos(stats, quantidadeDeEquipas);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                System.out.println(CYAN_BOLD + "A classificação de todas as equipas foi calculada e armazenada.");
                                break;
                            } else {
                                System.out.println(ANSI_RED + "Nesse caso não é possível executar esta funcionalidade.");
                            }
                            break;
                        }
                    case "5"://Listar a classificação das equipas por grupo.
                        Scanner lerResposta10 = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            quantidadeDeEquipas = quantidadeEquipas(stats);
                            diferencaGolos(stats, quantidadeDeEquipas);
                            classificacoes(ident, stats);
                            verificacao = 4;
                            listarClassificacoes(ident, stats, quantidadeDeEquipas);
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Não tem quaisquer dados em memoria!");
                            System.out.println(ANSI_WHITE);
                            System.out.println("Deseja executar os comandos 1, 2, 3, 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerResposta10.next();
                            System.out.println();
                            if (resposta.equalsIgnoreCase("Sim")) {
                                leituraDoFicheiro(ident, stats);
                                quantidadeDeEquipas = quantidadeEquipas(stats);
                                diferencaGolos(stats, quantidadeDeEquipas);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                verificacao = 4;
                                listarClassificacoes(ident, stats, quantidadeDeEquipas);
                                break;
                            } else {
                                System.out.println("Nesse caso não é possível executar esta funcionalidade.");
                            }
                            break;
                        }
                    case "6"://Listar as seleções cujos golos marcados é igual ao máximo de golos marcados.
                        Scanner lerResposta9 = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            quantidadeDeEquipas = quantidadeEquipas(stats);
                            diferencaGolos(stats, quantidadeDeEquipas);
                            classificacoes(ident, stats);
                            verificacao = 4;
                            listarGolosMarcados(ident, stats, quantidadeDeEquipas);
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Não tem quaisquer dados em memória!");
                            System.out.println(ANSI_WHITE);
                            System.out.println("Deseja executar os comandos 1, 2, 3 e 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerResposta9.next();
                            System.out.println();
                            if (resposta.equalsIgnoreCase("sim")) {
                                leituraDoFicheiro(ident, stats);
                                quantidadeDeEquipas = quantidadeEquipas(stats);
                                diferencaGolos(stats, quantidadeDeEquipas);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                verificacao = 4;
                                listarGolosMarcados(ident, stats, quantidadeDeEquipas);
                                break;
                            }
                            break;
                        }
                    case "7"://Listar as equipas com um determinado número de golos sofridos (inserir posteriormente o número de golos sofridos).
                        Scanner lerResposta8 = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            quantidadeDeEquipas = quantidadeEquipas(stats);
                            diferencaGolos(stats, quantidadeDeEquipas);
                            classificacoes(ident, stats);
                            verificacao = 4;
                            listarGolosSofridos(ident, stats, quantidadeDeEquipas);
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Nao tem quaisquer dados em memoria");
                            System.out.println(ANSI_WHITE);
                            System.out.println("Deseja executar os comandos 1, 2, 3 e 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerResposta8.next();
                            System.out.println();
                            if (resposta.equals("sim")) {
                                leituraDoFicheiro(ident, stats);
                                quantidadeDeEquipas = quantidadeEquipas(stats);
                                diferencaGolos(stats, quantidadeDeEquipas);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                verificacao = 4;
                                listarGolosSofridos(ident, stats, quantidadeDeEquipas);
                                break;
                            }
                            break;
                        }
                    case "8"://Listar as equipas que têm mais golos sofridos do que golos marcados, ordenadas alfabeticamente.
                        Scanner lerRespostaDesteModulo = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            quantidadeDeEquipas = quantidadeEquipas(stats);
                            diferencaGolos(stats, quantidadeDeEquipas);
                            pontuacao(ident, stats);
                            classificacoes(ident, stats);
                            verificacao = 4;
                            maisGolosSofridosEMarcados(ident, stats, quantidadeDeEquipas);
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Nao tem quaisquer dados em memoria");
                            System.out.println(ANSI_WHITE);
                            System.out.println("Deseja executar os comandos 1, 2, 3 e 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerRespostaDesteModulo.next();
                            System.out.println();
                            if (resposta.equals("sim")) {
                                leituraDoFicheiro(ident, stats);
                                quantidadeDeEquipas = quantidadeEquipas(stats);
                                diferencaGolos(stats, quantidadeDeEquipas);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                verificacao = 4;
                                maisGolosSofridosEMarcados(ident, stats, quantidadeDeEquipas);
                                break;
                            }
                            break;
                        }
                    case "9"://Listar o primeiro classificado de cada grupo.
                        Scanner lerRespostaDesteModulo2 = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            quantidadeDeEquipas = quantidadeEquipas(stats);
                            diferencaGolos(stats, quantidadeDeEquipas);
                            pontuacao(ident, stats);
                            classificacoes(ident, stats);
                            verificacao = 4;
                            primeiroClassificadoDeCadaGrupo(ident, stats, quantidadeDeEquipas);
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Nao tem quaisquer dados em memoria");
                            System.out.println(ANSI_WHITE);
                            System.out.println("Deseja executar os comandos 1, 2, 3 e 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerRespostaDesteModulo2.next();
                            System.out.println();
                            if (resposta.equals("sim")) {
                                leituraDoFicheiro(ident, stats);
                                quantidadeDeEquipas = quantidadeEquipas(stats);
                                diferencaGolos(stats, quantidadeDeEquipas);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                verificacao = 4;
                                primeiroClassificadoDeCadaGrupo(ident, stats, quantidadeDeEquipas);
                                break;
                            }
                            break;
                        }
                    case "10"://Listar informação completa de uma equipa (inserir posteriormente o nome da equipa).
                        Scanner lerResposta = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            quantidadeDeEquipas = quantidadeEquipas(stats);
                            diferencaGolos(stats, quantidadeDeEquipas);
                            pontuacao(ident, stats);
                            classificacoes(ident, stats);
                            verificacao = 4;
                            informacaoSelecao(ident, stats, quantidadeDeEquipas);
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Nao tem quaisquer dados em memoria");
                            System.out.println(ANSI_WHITE);
                            System.out.println("Deseja executar os comandos 1, 2, 3 e 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerResposta.next();
                            System.out.println();
                            if (resposta.equals("sim")) {
                                leituraDoFicheiro(ident, stats);
                                quantidadeDeEquipas = quantidadeEquipas(stats);
                                diferencaGolos(stats, quantidadeDeEquipas);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                verificacao = 4;
                                informacaoSelecao(ident, stats, quantidadeDeEquipas);
                                break;
                            }
                            break;
                        }
                    case "11"://Criar um ficheiro de texto com estatísticas dos jogos.
                        Scanner lerResposta4 = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            quantidadeDeEquipas = quantidadeEquipas(stats);
                            diferencaGolos(stats, quantidadeDeEquipas);
                            pontuacao(ident, stats);
                            classificacoes(ident, stats);
                            verificacao = 4;
                            estatisticaJogos(ident, stats, quantidadeDeEquipas);
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Nao tem quaisquer dados em memoria");
                            System.out.println(ANSI_WHITE);
                            System.out.println("Deseja executar os comandos 1, 2, 3 e 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerResposta4.next();
                            System.out.println();
                            if (resposta.equals("sim")) {
                                leituraDoFicheiro(ident, stats);
                                quantidadeDeEquipas = quantidadeEquipas(stats);
                                diferencaGolos(stats, quantidadeDeEquipas);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                verificacao = 4;
                                estatisticaJogos(ident, stats, quantidadeDeEquipas);
                                break;
                            } else {
                                System.out.println(ANSI_RED + "Nesse caso não é possível executar esta funcionalidade.");
                            }
                            break;
                        }
                    case "12"://Remover da memória as equipas que não vão disputar a fase seguinte (3º e 4º classificados de cada grupo).
                        Scanner ler = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            System.out.printf("\n%s\n%s\n", "Ao executar este comando vai eliminar todos os 3º e 4º de cada grupo da memoria!", "Deseja continuar? (Sim/Nao)");
                            System.out.println();
                            resposta = ler.next();
                            System.out.println();
                            if (resposta.equalsIgnoreCase("Sim")) {
                                Scanner lerResposta14 = new Scanner(System.in);
                                if (stats[0][0] != 0 && verificacao == 4) {
                                    pontuacao(ident, stats);
                                    classificacoes(ident, stats);
                                    verificacao = 4;
                                    removerTerceiroEQuarto(ident, stats, quantidadeDeEquipas);
                                    System.out.println(CYAN_BOLD + "As equipas que não vão disputar a fase seguinte foram removidas.");
                                    break;
                                } else {
                                    System.out.println(ANSI_RED + "Nao tem quaisquer dados em memoria");
                                    System.out.println(ANSI_WHITE);
                                    System.out.println("Deseja executar os comandos 1, 2, 3 e 4? (Sim/Nao)");
                                    System.out.println();
                                    resposta = lerResposta14.next();
                                    System.out.println();
                                    if (resposta.equalsIgnoreCase("sim")) {
                                        leituraDoFicheiro(ident, stats);
                                        pontuacao(ident, stats);
                                        classificacoes(ident, stats);
                                        verificacao = 4;
                                        removerTerceiroEQuarto(ident, stats, quantidadeDeEquipas);
                                        System.out.println(CYAN_BOLD + "As equipas que não vão disputar a fase seguinte foram removidas.");
                                        break;
                                    } else {
                                        System.out.println(ANSI_RED + "Nesse caso não é possível executar esta funcionalidade.");
                                    }
                                    break;
                                }
                            }
                        }
                        break;
                    case "13"://Criar um ficheiro de texto com as equipas que vão disputar a fase seguinte do campeonato.
                        Scanner lerResposta5 = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            pontuacao(ident, stats);
                            classificacoes(ident, stats);
                            verificacao = 4;
                            removerTerceiroEQuarto(ident, stats, quantidadeDeEquipas);
                            faseSeguinteDoMundial(ident, stats, quantidadeDeEquipas); //Remove todas as equipas que nao vao passar a fase final, ou seja, as 3 e 4 lugar
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Nao tem quaisquer dados em memoria");
                            System.out.println(ANSI_WHITE + "Deseja executar os comandos 1, 2, 3 e 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerResposta5.next();
                            System.out.println();
                            if (resposta.equalsIgnoreCase("sim")) {
                                leituraDoFicheiro(ident, stats);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                verificacao = 4;
                                removerTerceiroEQuarto(ident, stats, quantidadeDeEquipas);
                                faseSeguinteDoMundial(ident, stats, quantidadeDeEquipas);
                                break;
                            } else {
                                System.out.println(ANSI_RED + "Nesse caso não é possível executar esta funcionalidade.");
                            }
                            break;
                        }
                    case "14"://Criar um ficheiro de texto com os jogos da fase final.
                        Scanner lerResposta7 = new Scanner(System.in);
                        if (stats[0][0] != 0 && verificacao == 4) {
                            jogosFaseFinalDoMundial(ident, stats, quantidadeDeEquipas);
                            break;
                        } else {
                            System.out.println(ANSI_RED + "Nao tem quaisquer dados em memoria");
                            System.out.println(ANSI_WHITE);
                            System.out.println("Deseja executar os comandos 1, 2, 3 e 4? (Sim/Nao)");
                            System.out.println();
                            resposta = lerResposta7.next();
                            System.out.println();
                            if (resposta.equalsIgnoreCase("sim")) {
                                leituraDoFicheiro(ident, stats);
                                quantidadeDeEquipas = quantidadeEquipas(stats);
                                diferencaGolos(stats, quantidadeDeEquipas);
                                pontuacao(ident, stats);
                                classificacoes(ident, stats);
                                verificacao = 4;
                                jogosFaseFinalDoMundial(ident, stats, quantidadeDeEquipas);
                            } else {
                                System.out.println(ANSI_RED + "Nesse caso não é possível executar esta funcionalidade.");
                            }
                            break;
                        }
                    default:
                        System.out.println(ANSI_RED + "           ⚠Não existe essa funcionalidade. Digite um novo comando dentro do nosso intervalo (1-14) ou 'Sair' para terminar:⚠            ");
                }
                System.out.println();
                System.out.println(ANSI_WHITE + "O que deseja executar agora?");
                System.out.println();
                comando = lerResposta.nextLine();
                System.out.println();
            }
            System.out.println(ANSI_BLUE + "                          \uD83D\uDEC8 Obrigado por usar o nosso programa! Espero ter ajudado em tudo! Até à próxima! \uD83D\uDEC8   ️️️                   ");
            System.out.println();
            System.out.println("  ---------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println();
            System.out.println("                                                      🏆 ------------------------- 🏆");
            System.out.println("                                                     🏆          CRÉDITOS         🏆");
            System.out.println("                                                    🏆                           🏆");
            System.out.println("                                                   🏆  José Soares, nº1190782   🏆");
            System.out.println("                                                  🏆                           🏆");
            System.out.println("                                                 🏆  Lourenço Melo, nº1190811 🏆");
            System.out.println("                                                🏆                           🏆");
            System.out.println("                                               🏆 ------------------------- 🏆");

        } else {
            System.out.println(ANSI_BLUE + "                          \uD83D\uDEC8 Obrigado por usar o nosso programa! Espero ter ajudado em tudo! Até à próxima! \uD83D\uDEC8   ️️️                   ");
            System.out.println();
            System.out.println("  ---------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println();
            System.out.println("                                                      🏆 ------------------------- 🏆");
            System.out.println("                                                     🏆          CRÉDITOS         🏆");
            System.out.println("                                                    🏆                           🏆");
            System.out.println("                                                   🏆  José Soares, nº1190782   🏆");
            System.out.println("                                                  🏆                           🏆");
            System.out.println("                                                 🏆  Lourenço Melo, nº1190811 🏆");
            System.out.println("                                                🏆                           🏆");
            System.out.println("                                               🏆 ------------------------- 🏆");
        }
    }

    //----------------------------------------------------------------------------------------------------------------------------------------------------------------
    private static void leituraDoFicheiro(String[][] ident, int[][] stats) throws FileNotFoundException {
        Scanner in = new Scanner(new File("PracticalWork.csv"));
        String linha = in.nextLine();
        int quantidadeDeEquipas = 0;
        while (in.hasNext()) {
            linha = in.nextLine();
            String[] itens = linha.split(",");
            ident[quantidadeDeEquipas][0] = itens[0];
            ident[quantidadeDeEquipas][1] = itens[1];

            for (int i = 0, posicao = 2; posicao < itens.length; i++, posicao++) {
                stats[quantidadeDeEquipas][i] = Integer.parseInt(itens[posicao]);
            }
            quantidadeDeEquipas++;
        }

        if (stats[quantidadeDeEquipas][0] != 0) {
            for (int x = quantidadeDeEquipas; x < MAX_SELECOES; x++) {
                ident[x][0] = "null";
                ident[x][0] = "null";
                for (int t = 0; t < MAX_STATS; t++) {
                    stats[x][t] = 0;
                }
            }
        }
        in.close();
    }

    //----------------------------------------------------------------------------------------------------------------------------------------------------------------

    private static void acrescentar(String[][] ident, int[][] stats) throws FileNotFoundException {

        System.out.println("Escreva os dados a acrescentar neste formato: Grupo,Equipa,Jogos,Vitorias,Empates,Derrotas,GolosMarcados,GolosSofridos");
        System.out.println();
        String linha = lerResposta.nextLine();
        String itens[] = linha.split(",");

        if (itens.length == 8) {
            int quantidadeDeEquipas = quantidadeEquipas(stats);
            boolean bandeira = eSelecaoNova(ident, quantidadeDeEquipas, itens), confirmar = false;
            ;

            if (bandeira == true) {
                ident[quantidadeDeEquipas][0] = itens[0];
                ident[quantidadeDeEquipas][1] = itens[1];
                for (int i = 0, x = 2; x < itens.length; i++, x++) {
                    stats[quantidadeDeEquipas][i] = Integer.parseInt(itens[x]);
                }
                System.out.println();
                System.out.println(CYAN_BOLD + "A seleção foi acrescentada com sucesso.");
            } else {
                System.out.println();
                System.out.println(ANSI_RED + "A seleção já se encontra no mundial.");
            }
        } else {
            System.out.println();
            System.out.println("ERRO: A estrutura não é respeitada");
        }
    }

    //----------------------------------------------------------------------------------------------------------------------------------------------------------------

    private static boolean eSelecaoNova(String[][] ident, int quantidadeDeEquipas, String[] itens) {
        boolean bandeira = true;
        for (int i = 0; i < quantidadeDeEquipas; i++) {
            if (ident[i][1].equalsIgnoreCase(itens[1])) {
                bandeira = false;
            }
        }
        return bandeira;
    }

    //----------------------------------------------------------------------------------------------------------------------------------------------------------------

    private static int[][] pontuacao(String[][] ident, int[][] stats) throws FileNotFoundException {
        int quantidadeDeEquipas = quantidadeEquipas(stats);
        for (int i = 0; i < quantidadeDeEquipas; i++) {
            stats[i][7] = (stats[i][1] * 3) + (stats[i][2]);
        }
        return stats;
    }

    //----------------------------------------------------------------------------------------------------------------------------------------------------------------

    private static int[][] diferencaGolos(int[][] stats, int quantidadeDeEquipas) throws FileNotFoundException {
        for (int i = 0; i < quantidadeDeEquipas; i++) {
            stats[i][6] = (stats[i][4] - stats[i][5]);
        }
        return stats;
    }

    //----------------------------------------------------------------------------------------------------------------------------------------------------------------

    private static int quantidadeEquipas(int[][] stats) {
        int quantidadeDeEquipas = 0;
        while (stats[quantidadeDeEquipas][0] != 0) {
            quantidadeDeEquipas++;
        }
        return quantidadeDeEquipas;
    }

    //----------------------------------------------------------------------------------------------------------------------------------------------------------------

    private static void classificacoes(String[][] ident, int[][] stats) throws FileNotFoundException {

        int quantidadeDeEquipas = quantidadeEquipas(stats);

        for (int x = 0; x < quantidadeDeEquipas; x++) {
            for (int y = x + 1; y < quantidadeDeEquipas; y++) {
                if (stats[x][7] < stats[y][7]) {
                    int[] aux1 = stats[x];
                    stats[x] = stats[y];
                    stats[y] = aux1;

                    //vai trocar os grupos e selecoes conforme as posicoes
                    String[] aux2 = ident[x];
                    ident[x] = ident[y];
                    ident[y] = aux2;
                }
            }
        }

        for (int x = 0; x < quantidadeDeEquipas; x++) {
            for (int y = x + 1; y < quantidadeDeEquipas; y++) {
                if (stats[x][7] == stats[y][7]) {
                    if (stats[x][4] < stats[y][4]) {

                        //vai trocar os grupos e selecoes conforme as os golos marcados (caso a pontuacao seja igual)
                        String[] aux2 = ident[x];
                        ident[x] = ident[y];
                        ident[y] = aux2;

                        //vai trocar os dados conforme os golos marcados (caso a pontuacao seja igual)
                        int[] aux3 = stats[x];
                        stats[x] = stats[y];
                        stats[y] = aux3;

                    } else if (stats[x][4] == stats[y][4] && stats[x][5] > stats[y][5]) {
                        //vai trocar os grupos e selecoes conforme golos sofridos(menos golos melhor) (caso a pontuacao e os golos marcados seja igual)
                        String[] aux2 = ident[x];
                        ident[x] = ident[y];
                        ident[y] = aux2;

                        //vai trocar os dados conforme os golos sofridos(menos golos melhor) (caso a pontuacao e os golos marcados seja igual)
                        int[] aux3 = stats[x];
                        stats[x] = stats[y];
                        stats[y] = aux3;
                    } else if (stats[x][4] == stats[y][4] && stats[x][5] == stats[y][5] && ident[x][1].compareTo(ident[y][1]) > 0) {
                        //vai trocar os grupos e selecoes por ordem alfabetica (caso a pontuacao, os golos marcados e os golos sofridos seja igual)
                        String[] aux2 = ident[x];
                        ident[x] = ident[y];
                        ident[y] = aux2;

                        //vai trocar os dados por ordem alfabetica (caso a pontuacao, os golos marcados e os golos sofridos seja igual)
                        int[] aux3 = stats[x];
                        stats[x] = stats[y];
                        stats[y] = aux3;
                    }
                }
            }
        }

        //depois das equipas estarem corretamente ordenadas por pontos, vai ordenar pelos grupos e atribuir a posicao a cada uma delas
        String[][] aux1 = new String[quantidadeDeEquipas][MAX_IDENT];
        int[][] aux2 = new int[quantidadeDeEquipas][MAX_STATS];
        int[] posicao = new int[quantidadeDeEquipas];
        int t = 0, confirmar = 0;
        String[] grupos = {"a", "b", "c", "d", "e", "f", "g", "h"};
        for (int grupo = 0; grupo < grupos.length; grupo++) {
            int posicao1 = 1;
            for (int i = 0; i < quantidadeDeEquipas; i++) {
                if (ident[i][0].equalsIgnoreCase(grupos[grupo])) {
                    aux1[t] = ident[i];
                    aux2[t] = stats[i];
                    posicao[t] = posicao1;                // vai acrescentar a posicao de cada equipa no seu grupo aos dados na coluna 7
                    posicao1++;
                    t++;
                    confirmar++;
                }
            }
            if (confirmar == quantidadeDeEquipas) {
                break;
            }
        }

        for (int i = 0; i < quantidadeDeEquipas; i++) { //precissas de passar linha a linha para que o valor final passe bem....... eu antes estava simplesmente a igual as matrizes, tip aux1 = id;
            ident[i] = aux1[i];
            stats[i] = aux2[i];
            for (int x = 0; x < quantidadeDeEquipas; x++) {
                stats[x][8] = posicao[x];
            }
        }
    }

    //----------------------------------------------------------------------------------------------------------------------------------------------------------------

    private static void listarClassificacoes(String[][] ident, int[][] stats, int quantidadeDeEquipas) {

        System.out.printf("\n|%-5s|%5s|%-17s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|\n", "Grp", "Pos", "Equipa", "Pts", "J", "V", "E", "D", "GM", "GS", "GD");
        System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        System.out.printf("|%-5s|%5d|%-17s|%4d|%4d|%4d|%4d|%4d|%4d|%4d|%4d|\n", ident[0][0], stats[0][8], ident[0][1], stats[0][7], stats[0][0], stats[0][1], stats[0][2], stats[0][3], stats[0][4], stats[0][5], stats[0][6]);
        for (int i = 1; i < quantidadeDeEquipas; i++) {
            if (!ident[i][0].equalsIgnoreCase(ident[i - 1][0])) {
                System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
            }
            System.out.printf("|%-5s|%5d|%-17s|%4d|%4d|%4d|%4d|%4d|%4d|%4d|%4d|\n", ident[i][0], stats[i][8], ident[i][1], stats[i][7], stats[i][0], stats[i][1], stats[i][2], stats[i][3], stats[i][4], stats[i][5], stats[i][6]);
        }
        System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
    }
    //===================================================================================================================================================================

    private static void listarGolosMarcados(String[][] ident, int[][] stats, int quantidadeDeEquipas) {
        int maior = 0, x = 0;
        for (int i = 0; i < quantidadeDeEquipas; i++) {
            if (stats[i][4] > maior) {
                maior = stats[i][4];
            }
        }
        System.out.printf("|%-5s|%5s|%-17s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|\n", "Grp", "Pos", "Equipa", "Pts", "J", "V", "E", "D", "GM", "GS", "GD");
        System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        for (int i = 0; i < quantidadeDeEquipas; i++) {
            if (stats[i][4] == maior) {
                System.out.printf("|%-5s|%5d|%-17s|%4d|%4d|%4d|%4d|%4d|%4d|%4d|%4d|\n", ident[i][0], stats[i][8], ident[i][1], stats[i][7], stats[i][0], stats[i][1], stats[i][2], stats[i][3], stats[i][4], stats[i][5], stats[i][6]);
                System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
                x++;
            }
        }
    }

    //===================================================================================================================================================================

    private static void listarGolosSofridos(String[][] ident, int[][] stats, int quantidadeDeEquipas) {

        Scanner ler = new Scanner(System.in);
        System.out.println("Que quantidade de golos sofridos deseja procurar?");
        System.out.println();
        int golosSofridos = ler.nextInt();
        System.out.println();
        boolean flag = false;

        for (int i = 0; i < quantidadeDeEquipas; i++) {
            if (stats[i][5] == golosSofridos) {
                if (flag == false) {
                    System.out.printf("|%-5s|%5s|%-17s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|\n", "Grp", "Pos", "Equipa", "Pts", "J", "V", "E", "D", "GM", "GS", "GD");
                    System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
                }
                System.out.printf("|%-5s|%5d|%-17s|%4d|%4d|%4d|%4d|%4d|%4d|%4d|%4d|\n", ident[i][0], stats[i][8], ident[i][1], stats[i][7], stats[i][0], stats[i][1], stats[i][2], stats[i][3], stats[i][4], stats[i][5], stats[i][6]);
                flag = true;
                System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
            }
        }

        if (flag == false) {
            System.out.println(ANSI_RED + "Nao há nenhuma equipa com essa quantidade de golos sofridos.");
        }
    }

    //===================================================================================================================================================================

    private static void maisGolosSofridosEMarcados(String[][] ident, int[][] stats, int quantidadeDeEquipas) throws FileNotFoundException {
        String[][] arrIdent = new String[quantidadeDeEquipas][MAX_IDENT];
        int[][] arrStats = new int[quantidadeDeEquipas][MAX_STATS];
        int linha = 0;
        for (int i = 0; i < quantidadeDeEquipas; i++) {
            if (stats[i][5] > stats[i][4]) {
                arrIdent[linha] = ident[i];
                arrStats[linha] = stats[i];
                linha++;
            }
        }
        for (int x = 0; x < linha; x++) {
            for (int y = x + 1; y < linha; y++) {
                if (arrIdent[x][1].compareTo(arrIdent[y][1]) > 0) {
                    String[] aux1 = arrIdent[x];
                    arrIdent[x] = arrIdent[y];
                    arrIdent[y] = aux1;

                    int[] aux2 = arrStats[x];
                    arrStats[x] = arrStats[y];
                    arrStats[y] = aux2;
                }
            }
        }
        System.out.printf("|%-5s|%5s|%-17s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|\n", "Grp", "Pos", "Equipa", "Pts", "J", "V", "E", "D", "GM", "GS", "GD");
        System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        for (int i = 0; i < linha; i++) {
            System.out.printf("|%-5s|%5d|%-17s|%4d|%4d|%4d|%4d|%4d|%4d|%4d|%4d|\n", arrIdent[i][0], arrStats[i][8], arrIdent[i][1], arrStats[i][7], arrStats[i][0], arrStats[i][1], arrStats[i][2], arrStats[i][3], arrStats[i][4], arrStats[i][5], arrStats[i][6]);
            System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        }
    }

    //===================================================================================================================================================================

    private static void primeiroClassificadoDeCadaGrupo(String[][] ident, int[][] stats, int quantidadeDeEquipas) throws FileNotFoundException {

        System.out.printf("|%-5s|%5s|%-17s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|\n", "Grp", "Pos", "Equipa", "Pts", "J", "V", "E", "D", "GM", "GS", "GD");
        System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        System.out.printf("|%-5s|%5d|%-17s|%4d|%4d|%4d|%4d|%4d|%4d|%4d|%4d|\n", ident[0][0], stats[0][8], ident[0][1], stats[0][7], stats[0][0], stats[0][1], stats[0][2], stats[0][3], stats[0][4], stats[0][5], stats[0][6]);
        System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        for (int i = 1; i < quantidadeDeEquipas; i++) {
            if (!ident[i][0].equalsIgnoreCase(ident[i - 1][0])) {
                System.out.printf("|%-5s|%5d|%-17s|%4d|%4d|%4d|%4d|%4d|%4d|%4d|%4d|\n", ident[i][0], stats[i][8], ident[i][1], stats[i][7], stats[i][0], stats[i][1], stats[i][2], stats[i][3], stats[i][4], stats[i][5], stats[i][6]);
                System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
            }
        }
    }

    //===================================================================================================================================================================

    private static void informacaoSelecao(String[][] ident, int[][] stats, int quantidadeDeEquipas) throws FileNotFoundException {

        Scanner ler = new Scanner(System.in);
        System.out.println("Escreva o nome da equipa de que pretende obter a informacao completa.");
        System.out.println();
        String selecao = ler.nextLine();
        System.out.println();

        boolean flag = false;
        for (int i = 0; i < quantidadeDeEquipas; i++) {       //Vai percorrer cada equipa
            if (selecao.trim().equalsIgnoreCase(ident[i][1].trim())) {  //Se o nome da equipa escrito pelo utilizador for igual a  equipa dita por "i", entÃ£o serÃ¡ listada info da equipa
                System.out.printf("|%-5s|%5s|%-17s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|%4s|\n", "Grp", "Pos", "Equipa", "Pts", "J", "V", "E", "D", "GM", "GS", "GD");
                System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
                System.out.printf("|%-5s|%5d|%-17s|%4d|%4d|%4d|%4d|%4d|%4d|%4d|%4d|\n", ident[i][0], stats[i][8], ident[i][1], stats[i][7], stats[i][0], stats[i][1], stats[i][2], stats[i][3], stats[i][4], stats[i][5], stats[i][6]);
                System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
                flag = true;
                break;
            }
        }
        if (flag == false) {
            System.out.println(ANSI_RED + "Nao há nenhuma seleção com esse nome.");
        }
    }

    //===================================================================================================================================================================

    private static void estatisticaJogos(String[][] ident, int[][] stats, int quantidadeDeEquipas) throws FileNotFoundException {
        PrintWriter out = new PrintWriter(new File("Statistics.txt"));
        int totalVitorias = 0, totalEmpates = 0, totalDerrotas = 0;
        double totalJogos = 0, totalGM = 0, totalGS = 0;

        for (int i = 0; i < quantidadeDeEquipas; i++) {
            totalJogos = totalJogos + stats[i][0];
            totalVitorias = totalVitorias + stats[i][1];
            totalEmpates = totalEmpates + stats[i][2];
            totalDerrotas = totalDerrotas + stats[i][3];
            totalGM = totalGM + stats[i][4];
            totalGS = totalGS + stats[i][5];
        }

        double mediaGM = totalGM / totalJogos;
        double mediaGS = totalGS / totalJogos;

        out.println("Total de jogos= " + (int) totalJogos);
        out.println("Total de vitórias= " + totalVitorias);
        out.println("Total de empates= " + totalEmpates);
        out.println("Total de derrotas= " + totalDerrotas);
        out.println("Total de golos marcados= " + (int) totalGM);
        out.println("Total de golos sofridos= " + (int) totalGS);
        out.printf("Media de golos marcados por jogo= %.1f%n", mediaGM);
        out.printf("Media de golos sofridos por jogo= %.1f%n", mediaGS);

        System.out.println(CYAN_BOLD + "Ficheiro criado com sucesso!");

        out.close();
    }

    //===================================================================================================================================================================

    private static void removerTerceiroEQuarto(String[][] ident, int[][] stats, int quantidadeDeEquipas) {
        for (int i = 0; i < quantidadeDeEquipas; i++) {
            if (stats[i][8] == 3 || stats[i][8] == 4) {
                ident[i][0] = "";
                ident[i][1] = "ELIMINADO";
                for (int x = 0; x < MAX_STATS; x++) {
                    stats[i][x] = 0;
                }
            }
        }
    }

    //===================================================================================================================================================================

    private static void faseSeguinteDoMundial(String[][] ident, int[][] stats, int quantidadeDeEquipas) throws FileNotFoundException {

        PrintWriter out = new PrintWriter(new File("FinalStage.csv"));

        for (int i = 0; i < quantidadeDeEquipas; i++) {
            if (!ident[i][0].equals("")) {
                out.printf("%s,%d,%s,%d\n", ident[i][0], stats[i][8], ident[i][1], stats[i][7]);
            }
        }

        System.out.println(CYAN_BOLD + "Ficheiro criado com sucesso!");

        out.close();
    }

    private static void jogosFaseFinalDoMundial(String id[][], int stats[][], int quantidadeDeEquipas) throws FileNotFoundException {

        PrintWriter out = new PrintWriter(new File("FinalStageGames.txt"));

        String[][] jogos = new String[50][3];
        int t = 0;

        for (int i = 0; i < quantidadeDeEquipas; i++) {
            if (stats[i][8] == 1 || stats[i][8] == 2) {
                jogos[t][0] = id[i][0];
                jogos[t][1] = Integer.toString(stats[i][8]);
                jogos[t][2] = id[i][1];
                t++;
            }
        }

        int x = 0;
        while (x < t) {

            out.printf("%s,%s,%s-%s,%s,%s\n", jogos[x][0], jogos[x][1], jogos[x][2], jogos[x + 3][0], jogos[x + 3][1], jogos[x + 3][2]);
            out.printf("%s,%s,%s-%s,%s,%s\n", jogos[x + 1][0], jogos[x + 1][1], jogos[x + 1][2], jogos[x + 2][0], jogos[x + 2][1], jogos[x + 2][2]);

            x = x + 4;
        }

        System.out.printf(CYAN_BOLD + "\n%s\n", "Ficheiro criado com sucesso!");

        out.close();
    }
}